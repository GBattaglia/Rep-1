//
//  TableViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 13/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import AddressBookUI
import CoreLocation

var comande : [Comanda] = []
var nomeComanda : [String] = []
//var saveIndexComanda : Int!

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let comanda = Comanda()
        let count = 5
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        comanda.indirizzo = "viale vittorio veneto catania"
        comanda.nominativo = "Giuseppe B."
        comanda.orario = "21:30"
        comanda.quantità = 2
        comanda.note = "puntuale"
        comanda.pietanza = "Hamburger"
        comanda.ristorante = "Fud"
        comanda.id_Comanda = String(count + Int(arc4random()) % 2000)// mi genero un codice randomico per l'id dell'ordinazione
        comanda.accettata = false
        var placemark: CLPlacemark!
        CLGeocoder().geocodeAddressString(comanda.indirizzo, completionHandler: {(placemarks, error)->Void in
            if error == nil {
                
                placemark = placemarks![0]//lista delle vie
                comanda.coordinates = CLLocationCoordinate2DMake(placemark.location!.coordinate.latitude,placemark.location!.coordinate.longitude)
            }
        })
        comande.append(comanda)
        print(comanda.indirizzo)
        nomeComanda.append("Ordinazione-"+comanda.id_Comanda)
        print("Ordine inviato: "+comanda.id_Comanda)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return comande.count
        
        
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = comande[indexPath.row].id_Comanda + " " + comande[indexPath.row].nominativo
        //saveIndexComanda = indexPath.row
        cell.accessoryType = .disclosureIndicator
        return cell
    }
 
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destination = Storyboard.instantiateViewController(withIdentifier: "MasterViewController") as! MasterViewController
        comandaGestionale.id_Comanda = comande[indexPath.row].id_Comanda
        comandaGestionale.nominativo =  comande[indexPath.row].nominativo
        comandaGestionale.indirizzo =  comande[indexPath.row].indirizzo
        comandaGestionale.ristorante =  comande[indexPath.row].ristorante
        comandaGestionale.pietanza =  comande[indexPath.row].pietanza
        comandaGestionale.quantità =  comande[indexPath.row].quantità
        comandaGestionale.orario =  comande[indexPath.row].orario
        comandaGestionale.note =  comande[indexPath.row].note
        comandaGestionale.accettata = comande[indexPath.row].accettata
        self.navigationController?.pushViewController(destination, animated: true)
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
