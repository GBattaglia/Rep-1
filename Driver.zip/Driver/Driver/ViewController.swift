//
//  ViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 13/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import AddressBookUI
import CoreLocation
// var coordinates = CLLocationCoordinate2DMake(0,0)
class ViewController: UIViewController {
    var comanda = Comanda()
    var count = 0
    
    /*Acquisizione dati dalle textField*/
    
    @IBOutlet weak var nominativoLabel: UITextField!
    @IBOutlet weak var indirizzoLabel: UITextField!
    @IBOutlet weak var ristoranteLabel: UITextField!
    @IBOutlet weak var pietanzaLabel: UITextField!
    @IBOutlet weak var quantitàLabel: UITextField!
    @IBOutlet weak var orarioLabel: UITextField!
    @IBOutlet weak var noteLabel: UITextField!
    @IBAction func completaOrdine(_ sender: Any) {
        
        comanda.indirizzo = indirizzoLabel.text!
        comanda.nominativo = nominativoLabel.text!
        comanda.orario = orarioLabel.text!
        comanda.quantità = Int(quantitàLabel.text!)!
        comanda.note = noteLabel.text!
        comanda.pietanza = pietanzaLabel.text!
        comanda.ristorante = ristoranteLabel.text!
        comanda.id_Comanda = String(count + Int(arc4random()) % 2000)// mi genero un codice randomico per l'id dell'ordinazione
        comanda.accettata = false
        
        var placemark: CLPlacemark!
        CLGeocoder().geocodeAddressString(indirizzoLabel.text!, completionHandler: {(placemarks, error)->Void in
            if error == nil {
                
                placemark = placemarks![0]//lista delle vie
                self.comanda.coordinates = CLLocationCoordinate2DMake(placemark.location!.coordinate.latitude,placemark.location!.coordinate.longitude)
            }
        })
        comande.append(comanda)
        print(comanda.indirizzo)
        nomeComanda.append("Ordinazione-"+comanda.id_Comanda)
        print("Ordine inviato: "+comanda.id_Comanda)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        nominativoLabel.resignFirstResponder()
        indirizzoLabel.resignFirstResponder()
        ristoranteLabel.resignFirstResponder()
        pietanzaLabel.resignFirstResponder()
        quantitàLabel.resignFirstResponder()
        orarioLabel.resignFirstResponder()
        noteLabel.resignFirstResponder()
    }

}

