//
//  FattorinoViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 14/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import AddressBookUI
import CoreLocation
//let regionDistance : CLLocationDistance = 1000
var comandaFtt = Comanda()
//var str = " "
class FattorinoViewController: UIViewController {
var mapOpen = false
    @IBOutlet weak var comandaFattorino: UITextView!
    @IBAction func AccettaConsegna(_ sender: Any) {
        comandaFtt.accettataDriver = true
        comandaFtt.orarioPartenza = DateFormatter.localizedString(from: Date(), dateStyle: DateFormatter.Style.short, timeStyle: DateFormatter.Style.short)
    }

    @IBAction func mostraDirezioni(_ sender: Any) {
        if comandaFtt.accettataDriver == true {
        let regionDistance : CLLocationDistance = 1000
        let regionSpan = MKCoordinateRegionMakeWithDistance(comandaFtt.coordinates,regionDistance,regionDistance)
        let option = [MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)]
        
        let placemark = MKPlacemark(coordinate:comandaFtt.coordinates)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = "Punto di Consegna"
        //openMap = true
            mapOpen = true
        mapItem.openInMaps(launchOptions: option)
        }
        else {
            mapOpen = false
            let myAlert = UIAlertController(title: "*ATTENZIONE*",message: "Devi accettare la consegna prima di poter visualizzare la mappa", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
        }
        
    }
    @IBAction func consegnato(_ sender: Any) {
        if comandaFtt.accettataDriver == true  && mapOpen == true{
        storicoComanda.append(comandaFtt)
        comandaFtt.orarioArrivo = DateFormatter.localizedString(from: Date(), dateStyle: DateFormatter.Style.short, timeStyle: DateFormatter.Style.short)
            //comande.remove(at: saveIndexComanda)
           // str = "Consegnato!"
            print(indexRowAction)
           comande.remove(at: indexRowAction)
            
        }
        else {
            let myAlert = UIAlertController(title: "*ATTENZIONE*",message: "Devi accettare la consegna o aprire la mappa per concludere la consegna", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
            comandaFtt.orarioArrivo = " "
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        comandaFattorino.text.append("ID Comanda: "+comandaFtt.id_Comanda+"\n")
        comandaFattorino.text.append("Nominativo: "+comandaFtt.nominativo+"\n")
        comandaFattorino.text.append("Indirizzo: "+comandaFtt.indirizzo+"\n")
        comandaFattorino.text.append("Ristorante: "+comandaFtt.ristorante+"\n")
        comandaFattorino.text.append("Cosa ha ordinato?: "+comandaFtt.pietanza+"\n")
        comandaFattorino.text.append("Quantità: "+String(comandaFtt.quantità)+"\n")
        comandaFattorino.text.append("Orario: "+comandaFtt.orario+"\n")
        comandaFattorino.text.append("Note: "+comandaFtt.note+"\n")
        //storicoComanda.append(comandaFtt)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
