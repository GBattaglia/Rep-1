//
//  Fattorino.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 13/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import Foundation
import MapKit
import AddressBookUI
import CoreLocation

class Fattorino{
    var comandeFattorino : [Comanda] = [ ]
    var id_Fattorino : String = " "
    var fondoCassa : Int = 30
    var cassa : Double = 0.0
    var tempoConsegna : String = " "
    
}
