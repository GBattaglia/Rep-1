//
//  ConsegnaViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 15/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
var storicoComanda : [Comanda] = []
class ConsegnaViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        return storicoComanda.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "archivio", for: indexPath)
        // Configure the cell...
        cell.textLabel?.text = storicoComanda[indexPath.row].id_Comanda + " " + storicoComanda[indexPath.row].nominativo + " " + storicoComanda[indexPath.row].orarioPartenza
        cell.accessoryType = .detailButton
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destination = Storyboard.instantiateViewController(withIdentifier: "comandaArchivio") as! comandaArchivioViewController
            comandaArchiviata = storicoComanda[indexPath.row]
         self.navigationController?.pushViewController(destination, animated: true)
    }


}
