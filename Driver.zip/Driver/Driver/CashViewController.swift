//
//  CashViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 14/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import AddressBookUI

var ini = 0.0
var flagPosition = false

class CashViewController: UIViewController , MKMapViewDelegate, CLLocationManagerDelegate {

    @IBAction func fineSerata(_ sender: Any) {
        fineSerataControl = true
        
    }
    @IBAction func svuotaCassa(_ sender: Any) {
        
        if fineSerataControl == true {
            ini = 0.0
            cassa.text = String(ini)
            fineSerataControl = false
        }
        else {
            let myAlert = UIAlertController(title: "*ATTENZIONE*",message: "NON PUOI SVUOTARE LA CASSA", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var fondoCassa: UITextView!
    @IBOutlet weak var cassa: UITextView!
    @IBOutlet weak var importo: UITextField!
    @IBAction func aggiungiacassa(_ sender: Any) {
       let saldo = Double(cassa.text!)! + Double(importo.text!)!
        cassa.text = String(saldo)
        ini = saldo
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        fondoCassa.text = "30€"
        cassa.text = String(ini)
        // Do any additional setup after loading the view.
        var fattorinoPosizione: CLLocationManager!
        fattorinoPosizione = CLLocationManager()
        fattorinoPosizione.delegate = self// imposto come delegato il viewcontroller corrente
        fattorinoPosizione.desiredAccuracy = kCLLocationAccuracyNearestTenMeters//setto l'accuratezza della posizione
        fattorinoPosizione.requestWhenInUseAuthorization() // funziona in foreGround
        fattorinoPosizione.startUpdatingLocation()// recupero posizione e aggiorno spostamenti
        print(String(describing: fattorinoPosizione))
        print("Posizione aggiornata")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        importo.resignFirstResponder()
    }

}
