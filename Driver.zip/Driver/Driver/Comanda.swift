//
//  Comanda.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 13/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import Foundation
import MapKit
import AddressBookUI
import CoreLocation

class Comanda{
    var id_Comanda : String = " "
    var nominativo : String = " "
    var indirizzo : String = " "
    var ristorante : String = " "
    var note : String = " "
    var quantità : Int = 0
    var orario : String = " "
    var pietanza : String = " "
    var accettata = false
    var accettataDriver = false
    var coordinates = CLLocationCoordinate2DMake(0,0)
    var orarioPartenza : String!
    var orarioArrivo : String!
    
}
