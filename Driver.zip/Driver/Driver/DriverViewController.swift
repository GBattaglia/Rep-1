//
//  DriverViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 14/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//



/*TABLE CONTROLLER FATTORINO*/



import UIKit
import MapKit
import AddressBookUI
import CoreLocation

var regionSpan = CLLocationCoordinate2DMake(0,0)
var fineSerataControl : Bool = false
var saveIndexComanda : Int!

var indexRowAction = 0

class DriverViewController: UITableViewController {
   // var ordinatePerOra : [Comanda] = []
    //var refresh : UIRefreshControl!
    var refresher : UIRefreshControl!
  
    @IBAction func apriPortafoglio(_ sender: Any) {
        let Storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destination = Storyboard.instantiateViewController(withIdentifier: "fattorinoCash") as! CashViewController
        //code insert here:
        
        self.navigationController?.pushViewController(destination, animated: true)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        //self.tableView.reloadData()
        refresher = UIRefreshControl()
        refresher.attributedTitle = NSAttributedString(string: "Scorri per aggiornare")
        refresher.addTarget(self, action: #selector(DriverViewController.spopulate), for: UIControlEvents.valueChanged)
        tableView.addSubview(refresher)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    //numero di righe della view
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return comande.count
    }
    //nome per ogni riga
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellDriver", for: indexPath)

        // Configure the cell...
        //ordinatePerOra = comandeAccettate.sorted(by: { $0.orario < $1.orario})
        
        cell.textLabel?.text = comande[indexPath.row].id_Comanda + " " + comande[indexPath.row].nominativo + " " + comande[indexPath.row].orario
        cell.accessoryType = .disclosureIndicator
        saveIndexComanda = indexPath.row
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let Storyboard = UIStoryboard(name: "Main", bundle: nil)
        let destination = Storyboard.instantiateViewController(withIdentifier: "fattorinoViewController") as! FattorinoViewController
        //code insert here:
        comandaFtt = comande[indexPath.row]
        indexRowAction = indexPath.row
        self.navigationController?.pushViewController(destination, animated: true)
        //tableView.reloadData()
    }
    func spopulate(){
        tableView.reloadData()
        refresher.endRefreshing()
    }
}
