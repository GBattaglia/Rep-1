//
//  comandaArchivioViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 15/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
var comandaArchiviata : Comanda!

class comandaArchivioViewController: UIViewController {

    @IBOutlet weak var titoloComanda: UILabel!
    @IBOutlet weak var comandatext: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //mostro i dettagli della comanda
        titoloComanda.text = comandaArchiviata.id_Comanda + " " + comandaArchiviata.orarioPartenza
        comandatext.text.append("ID Consegna: " + comandaArchiviata.id_Comanda + "\n")
        comandatext.text.append("Nominativo Cliente: " + comandaArchiviata.nominativo + "\n")
        comandatext.text.append("Indirizzo: " + comandaArchiviata.indirizzo + "\n")
        comandatext.text.append("Dove ha ordinato: " + comandaArchiviata.ristorante + "\n")
        comandatext.text.append("Cosa ha ordinato: " + String(comandaArchiviata.quantità) + "\n")
        comandatext.text.append("Orario : " + comandaArchiviata.orario + "\n")
        comandatext.text.append("Ora partenza: " + comandaArchiviata.orarioPartenza + "\n")
        comandatext.text.append("Ora Arrivo/Consegna: " + comandaArchiviata.orarioArrivo + "\n")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
