//
//  MasterViewController.swift
//  Driver
//
//  Created by Giuseppe Battaglia on 13/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import AddressBookUI
import CoreLocation

//var feed : Bool = false
var comandaGestionale : Comanda = Comanda()
var comandeAccettate : [Comanda] = []
class MasterViewController: UIViewController {
    
    /*@IBAction func switchAccetta(_ sender: UISwitch) {
        if sender.isOn == true {
            let myAlert = UIAlertController(title: "Ordinazione",message: "Hai accettato l'ordine", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
            comandaGestionale.accettata = true
            print(comandaGestionale.id_Comanda + "ordine accettato = "+String(comandaGestionale.accettata))
                comandeAccettate.append(comandaGestionale)
        }
    }*/
    @IBOutlet weak var ordinazioneLabelGestionale: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ordinazioneLabelGestionale.text.append("ID Comanda: "+comandaGestionale.id_Comanda+"\n")
        ordinazioneLabelGestionale.text.append("Nominativo: "+comandaGestionale.nominativo+"\n")
        ordinazioneLabelGestionale.text.append("Indirizzo: "+comandaGestionale.indirizzo+"\n")
        ordinazioneLabelGestionale.text.append("Ristorante: "+comandaGestionale.ristorante+"\n")
        ordinazioneLabelGestionale.text.append("Cosa ha ordinato?: "+comandaGestionale.pietanza+"\n")
        ordinazioneLabelGestionale.text.append("Quantità: "+String(comandaGestionale.quantità)+"\n")
        ordinazioneLabelGestionale.text.append("Orario: "+comandaGestionale.orario+"\n")
        ordinazioneLabelGestionale.text.append("Note: "+comandaGestionale.note+"\n")
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
