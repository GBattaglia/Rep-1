//
//  ViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 08/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
var passing_data = " "
class ViewController: UIViewController {

    @IBOutlet weak var Pswd: UITextField!
    @IBOutlet weak var Usr: UITextField!
    
    @IBAction func Accedi(_ sender: Any){
    
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //let stringa = "ciao"
        if Usr.text == "IdFattorino" && Pswd.text == "1234" {
            print("Accesso effettuato")
        }
        else{
            let myAlert = UIAlertController(title: "Attenzione",message: "Accesso Negato", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "Riprova", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

