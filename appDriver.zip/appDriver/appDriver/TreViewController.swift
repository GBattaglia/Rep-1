//
//  TreViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 10/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import AVFoundation
import AudioToolbox

class TreViewController: UIViewController {

    @IBOutlet weak var mostra: UITextView!
    @IBOutlet weak var qta: UITextView!
    @IBOutlet weak var prz: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // se l'ordine viene effettuato il gestionale emette un suono
        if ordineEffettuato == true {
            AudioServicesPlaySystemSound(SystemSoundID(1000))
        }
        
        for ordine in carrelloUser{
        mostra.text.append(ordine+"\n")
        }
        for quant in qtaItem{
            qta.text.append(quant+"\n")
        }
        //prz.text.append(String(prezzoUser))
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
