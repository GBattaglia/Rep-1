//
//  SecondViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 08/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
//37.506958, 15.085339    ****vicolo
//37.510417, 15.086377    ****FUD

/*COORDINATE RISTORANTI*/

var latVicolo : CLLocationDegrees = 37.506958
var longVicolo : CLLocationDegrees = 15.085339

var latFud : CLLocationDegrees = 37.510417
var longFud : CLLocationDegrees = 15.086377
/*COORDINATE CONSEGNA*/

var coordinates = CLLocationCoordinate2DMake(0,0)

/*variabili globali per passing_data*/
var carrelloUser: [String] = []
var prezzoUser : Float = 0.0
var qtaItem : [String] = []
var indirizzoVar: String = " "
var orarioVar: String = " "
var noteVar: String = " "
var nomeVar : String = " "
var ristoranteVar = " "
var ordineEffettuato : Bool = false // mi serve per emettere il suono


class SecondViewController: UIViewController {
    @IBOutlet weak var nome_cognome: UITextField!

    @IBOutlet weak var indirizzo: UITextField!
    @IBOutlet weak var ristorante: UITextField!
    @IBOutlet weak var orario: UITextField!
    @IBOutlet weak var cosa_ordinare: UITextField!
    @IBOutlet weak var quantità: UILabel!
    @IBOutlet weak var note: UITextField!
    
    
    @IBAction func incDec(_ sender: UIStepper) {
        quantità.text = String(sender.value)
    }
    var credenzialiAccess = String()//mantengo il log-in
    
    var ristoranti: [String] = ["Al vicolo","FUD"]
    var prezziVicolo:[Float] = [5,70,6.80]
    var prezziFud: [Float] = [6.10,5.80]
    var menuVicolo: [String] = ["Pizza","Panino","pizza","panino"]//5,70,6,60
    var menuFud: [String] = ["Panino","Insalata","panino","insalata"]//6,70,5,80
   // var indexInt = 0
    
    @IBAction func addItem(_ sender: Any) {
        
        /* Mi mantengo i dati del cliente*/
        indirizzoVar = indirizzo.text!
        nomeVar = nome_cognome.text!
        orarioVar = orario.text!
        noteVar = note.text!
        
        /*Prendo le coordinate della consegna*/
         var placemark: CLPlacemark!
        
         CLGeocoder().geocodeAddressString(indirizzo.text!, completionHandler: {(placemarks, error)->Void in
         if error == nil {
         
         placemark = placemarks![0]//lista delle vie
            coordinates = CLLocationCoordinate2DMake(placemark.location!.coordinate.latitude,placemark.location!.coordinate.longitude)
         }
         })
        
        /*Faccio una selezione */
        if ristorante.text == "FUD" {
            ristoranteVar = ristorante.text!
            carrelloUser.append(cosa_ordinare.text!)
            print(carrelloUser.count)
            if cosa_ordinare.text == "Panino" || cosa_ordinare.text == "panino" {
                qtaItem.append(quantità.text!)
                prezzoUser += prezziFud[0] * Float(quantità.text!)!
                print(prezzoUser)
            }
            else if cosa_ordinare.text == "Insalata" || cosa_ordinare.text == "insalata" {
                qtaItem.append(quantità.text!)
                prezzoUser += prezziFud[1] * Float(quantità.text!)!
            }
        }
        
        if ristorante.text == "Al Vicolo" {
            ristoranteVar = ristorante.text!
            carrelloUser.append(cosa_ordinare.text!)
            print(carrelloUser.count)
            if cosa_ordinare.text == "Pizza" || cosa_ordinare.text == "pizza" {
                qtaItem.append(quantità.text!)
                prezzoUser += prezziVicolo[0] * Float(quantità.text!)!
            }
            else if cosa_ordinare.text == "Panino" || cosa_ordinare.text == "panino" {
                qtaItem.append(quantità.text!)
                prezzoUser += prezziVicolo[1] * Float(quantità.text!)!
                
            }
        }
        ordineEffettuato = true 
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }

}
