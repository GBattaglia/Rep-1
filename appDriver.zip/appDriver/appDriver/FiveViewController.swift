//
//  FiveViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 11/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import AddressBookUI


/*COORDINATE FATTORINI*/

var yesorno : Bool = false

class FiveViewController: UIViewController {
    
    var openMap = false
    
    @IBAction func consegna(_ sender: Any) {
        
        if openMap == true && yesorno == true {
            let myAlert = UIAlertController(title: "Consegna Effettuata",message: "Notificato al gestionale", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
            }
        else {
            let myAlert = UIAlertController(title: "Errore",message: "Consegna non avvenuta!", preferredStyle: UIAlertControllerStyle.alert)
            myAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
            self.present(myAlert, animated: true, completion: nil)
        }
    }
    @IBAction func accettaConsegna(_ sender: Any) {
        if(yesorno == false){
        yesorno = true
        let myAlert = UIAlertController(title: "Accetta Consegna",message: "Hai inviato un Feed al Gestionale", preferredStyle: UIAlertControllerStyle.alert)
        myAlert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in myAlert.dismiss(animated: true, completion: nil)}))
        self.present(myAlert, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var mostramiId: UITextView!
    @IBAction func mostramiMaps(_ sender: Any) {
        
        let regionDistance : CLLocationDistance = 1000
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates,regionDistance,regionDistance)
        let option = [MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)]
        
        let placemark = MKPlacemark(coordinate: coordinates)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = "Punto di Consegna"
        openMap = true
        mapItem.openInMaps(launchOptions: option)

    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mostramiId.text.append(id)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
