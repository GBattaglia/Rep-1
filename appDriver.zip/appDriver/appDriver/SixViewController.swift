//
//  SixViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 11/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit

class SixViewController: UIViewController {

    @IBOutlet weak var mostraQta: UITextView!
    @IBOutlet weak var mostraOrdine: UITextView!
    @IBOutlet weak var mostraDati: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        mostraDati.text.append("Nominativo: " + nomeVar+"\n")
        mostraDati.text.append("Indirizzo: " + indirizzoVar+"\n")
        mostraDati.text.append("Locale: " + ristoranteVar+"\n")
        mostraDati.text.append("Ora consegna: " + orarioVar+"\n")
        mostraDati.text.append("Note: " + noteVar+"\n")
        
        for ordine in carrelloUser{
            mostraOrdine.text.append(ordine+"\n")
        }
        for quant in qtaItem{
            mostraQta.text.append(quant+"\n")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
