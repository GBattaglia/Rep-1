//
//  FourViewController.swift
//  appDriver
//
//  Created by Giuseppe Battaglia on 10/09/17.
//  Copyright © 2017 Giuseppe Battaglia. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import AddressBookUI

/*Ricevo i dati dell'ordinazione e la inoltro al fattorino*/
var latDriver1 : CLLocationDegrees = 37.509263
var longDriver1 : CLLocationDegrees = 15.084868
var latDriver2 : CLLocationDegrees = 37.510999
var longDriver2 : CLLocationDegrees = 15.086620
var idDriver1 : String = "idDriver1-31411r1r"
var idDriver2 : String = "idDriver2-r4r4244t"
var id = " "
class FourViewController: UIViewController {

    @IBOutlet weak var countFattorini: UITextView!
    @IBOutlet weak var dataView: UILabel!
    @IBOutlet weak var mostraOrdine: UITextView!
    @IBOutlet weak var mostraCibo: UITextView!
    @IBOutlet weak var mostraQta: UITextView!
    var fattorini : [String] = [idDriver1,idDriver2]
    
    override func viewDidLoad() {
        super.viewDidLoad()

         dataView.text = DateFormatter.localizedString(from: Date(), dateStyle: DateFormatter.Style.short, timeStyle: DateFormatter.Style.short)
        mostraOrdine.text.append("Nominativo: " + nomeVar+"\n")
        mostraOrdine.text.append("Indirizzo: " + indirizzoVar+"\n")
        mostraOrdine.text.append("Locale: " + ristoranteVar+"\n")
        mostraOrdine.text.append("Ora consegna: " + orarioVar+"\n")
        mostraOrdine.text.append("Note: " + noteVar+"\n")
        
        
        for ordine in carrelloUser{
            mostraCibo.text.append(ordine+"\n")
        }
        for quant in qtaItem{
            mostraQta.text.append(quant+"\n")
        }
        countFattorini.text.append(String(fattorini.count))
        
        //trasformo in numeri le coordinate
        let num1 = Double(latDriver1 - longDriver1)
        let num2 = Double(latDriver2 - longDriver2)
        let locale1 = Double(latVicolo - longVicolo)
        let locale2 = Double(latFud - longFud)
     
        switch ristoranteVar {
        case "Al Vicolo" :
            if num1 > num2 && num1 > locale1 && (num2 > locale1 || num2 < locale1){
                    print("fattorino 2")
                    id = idDriver2
            }
            else {
                print("fattorino 1")
                id = idDriver1
            }
        case "FUD" :
            if num1 > num2 && num1 > locale2 && (num2 > locale2 || num2 < locale2){
                print("fattorino 2")
                id = idDriver2
            }
            else {
                print("fattorino 1")
                id = idDriver1
            }
            
        default: break
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
